import React, { useEffect, useState } from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Datasets from './pages/Datasets';
import Indicadors from './pages/Indicadors';
import Sinistralitat from './pages/Sinistralitat';
import Factors from './pages/Factors';
import Informe from './pages/Informe';
import Configuracio from './pages/Configuracio';
import Login from './pages/Login';
import GrafanaDashboard from './pages/GrafanaDashboard';
import AccidentProbability from './pages/AccidentProbability';
import Registre from './pages/Registre';
import { AuthProvider, useAuth } from './AuthContext';
import { ChatbotWidget } from './components/ChatbotWidget';

// Standalone embed mode — renders just the requested view with no chrome
function EmbedView() {
  const params = new URLSearchParams(window.location.search);
  const view = params.get('view');
  if (view === 'grafana') return <GrafanaDashboard />;
  if (view === 'probabilitat') return <AccidentProbability />;
  if (view === 'registre') return <Registre />;
  return <div style={{ color: '#fff', padding: 20 }}>Unknown embed view: {view}</div>;
}

function AppContent() {
  const [activeSection, setActiveSection] = useState('inici');
  const { user, logout } = useAuth();

  useEffect(() => {
    if (user && activeSection === 'login') {
      setActiveSection('configuracio');
    }
  }, [user, activeSection]);

  const renderContent = () => {
    switch (activeSection) {
      case 'datasets': return <Datasets />;
      case 'indicadors': return <Indicadors />;
      case 'sinistralitat': return <Sinistralitat />;
      case 'probabilitat': return <AccidentProbability />;
      case 'registre': return <Registre />;
      case 'factors': return <Factors />;
      case 'informe': return <Informe />;
      case 'configuracio': return <Configuracio />;
      case 'login': return <Login />;
      case 'inici':
      default: return <Dashboard />;
    }
  };

  return (
    <div className="App">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <div className="main-content">
        <header className="app-header">
          <h1 className="page-title">
            {activeSection === 'inici' && '🗺️ Mapa de tràfic'}
            {activeSection === 'indicadors' && '📊 Indicadors de trànsit'}
            {activeSection === 'sinistralitat' && '🚨 Sinistralitat'}
            {activeSection === 'probabilitat' && "🎯 Probabilitat d'accidents"}
            {activeSection === 'registre' && '🗃️ Registre'}
            {activeSection === 'factors' && '🌤️ Factors externs'}
            {activeSection === 'datasets' && '📁 Datasets'}
            {activeSection === 'informe' && '📋 Informe setmanal'}
            {activeSection === 'configuracio' && '⚙️ Configuració'}
            {activeSection === 'login' && '🔐 Login'}
          </h1>
          <div className="header-actions">
            {!user && (
              <button className="admin-cta" onClick={() => setActiveSection('login')}>
                <span className="admin-cta__icon">🔒</span>
                <div className="admin-cta__text">
                  <small>Accés restringit</small>
                  <span>Accés admin</span>
                </div>
              </button>
            )}
            {user && (
              <div className="user-chip">
                <div className="user-chip__info">
                  <small>Administrador</small>
                  <strong>{user}</strong>
                </div>
                <button className="chip-action" onClick={async () => { await logout(); setActiveSection('inici'); }}>
                  Sortir
                </button>
              </div>
            )}
          </div>
        </header>
        <div className="content-area">
          {renderContent()}
        </div>
        <ChatbotWidget />
      </div>
    </div>
  );
}

function App() {
  const isEmbed = new URLSearchParams(window.location.search).has('view');
  if (isEmbed) return <EmbedView />;
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
