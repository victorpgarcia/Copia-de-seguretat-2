import React, { useState } from 'react';
import './DatasetInsights.css';
import { useAuth } from '../AuthContext';

interface DatasetInsightsProps {
  datasetId: number;
  format: string;
  title: string;
}

const DatasetInsights: React.FC<DatasetInsightsProps> = ({ datasetId, format, title }) => {
  const { fetchWithAuth } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isXml = format.toUpperCase().includes('XML');

  const analyze = async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetchWithAuth(`/api/datasets/${datasetId}/analyze-xml`);
      if (!res.ok) { const d = await res.json(); setError(d.detail || 'Error analitzant'); return; }
      setData(await res.json());
    } catch (e) { setError('Error de connexió'); }
    finally { setLoading(false); }
  };

  const downloadTxt = async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetchWithAuth(`/api/datasets/${datasetId}/xml-to-txt`);
      if (!res.ok) { const d = await res.json(); setError(d.detail || 'Error'); return; }
      const json = await res.json();
      const blob = new Blob([json.content], { type: 'text/plain' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `dataset_${datasetId}.txt`;
      a.click();
    } catch (e) { setError('Error de connexió'); }
    finally { setLoading(false); }
  };

  const downloadXml = async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetchWithAuth(`/api/datasets/${datasetId}/xml-download`);
      if (!res.ok) { setError('Error descarregant'); return; }
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `dataset_${datasetId}.xml`;
      a.click();
    } catch (e) { setError('Error de connexió'); }
    finally { setLoading(false); }
  };

  if (!isXml) return null;

  return (
    <div className="dataset-insights">
      <div className="insights-actions">
        <button className="btn-insights" onClick={analyze} disabled={loading}>
          {loading ? '⏳ Analitzant…' : '🔍 Analitzar XML'}
        </button>
        <button className="btn-insights btn-insights--secondary" onClick={downloadTxt} disabled={loading}>
          📄 Exportar TXT
        </button>
        <button className="btn-insights btn-insights--secondary" onClick={downloadXml} disabled={loading}>
          ⬇️ Baixar XML
        </button>
      </div>
      {error && <p className="insights-error">⚠️ {error}</p>}
      {data && (
        <div className="insights-results">
          <h4>📊 Resultats: {title}</h4>
          <p><strong>Total incidències:</strong> {data.total}</p>
          {data.by_tipo && (
            <div className="insights-section">
              <h5>Per tipus:</h5>
              <ul>
                {Object.entries(data.by_tipo).slice(0, 8).map(([k, v]) => (
                  <li key={k}><span>{k}</span><strong>{v as number}</strong></li>
                ))}
              </ul>
            </div>
          )}
          {data.by_road_top10 && (
            <div className="insights-section">
              <h5>Carreteres més afectades:</h5>
              <ul>
                {data.by_road_top10.slice(0, 8).map(([k, v]: [string, number]) => (
                  <li key={k}><span>{k}</span><strong>{v}</strong></li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DatasetInsights;
