import React, { useState, useRef, useEffect } from 'react';
import './ChatbotWidget.css';

interface Message { role: 'user' | 'bot'; text: string; }

export const ChatbotWidget: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'bot', text: "Hola! Sóc l'assistent RACC. Pregunta'm sobre les incidències viàries de Catalunya." }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const send = async () => {
    const q = input.trim();
    if (!q || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', text: q }]);
    setLoading(true);
    try {
      const context = "Aplicació de mobilitat RACC amb dades d'incidències viàries de Catalunya. Fonts: SCT, Open Data BCN, TMB, AMB, Rodalies, DGT.";
      const res = await fetch('/api/chatbot/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context, question: q }),
      });
      const data = await res.json();
      setMessages(m => [...m, { role: 'bot', text: data.answer || data.error || 'Sense resposta.' }]);
    } catch {
      setMessages(m => [...m, { role: 'bot', text: 'Error de connexió amb el servidor.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chatbot-widget">
      {open && (
        <div className="chatbot-panel">
          <div className="chatbot-header">
            <span>🤖 Assistent RACC</span>
            <button className="chatbot-close" onClick={() => setOpen(false)}>✕</button>
          </div>
          <div className="chatbot-messages">
            {messages.map((m, i) => (
              <div key={i} className={`chatbot-msg chatbot-msg--${m.role}`}>
                <span className="chatbot-msg__text">{m.text}</span>
              </div>
            ))}
            {loading && (
              <div className="chatbot-msg chatbot-msg--bot">
                <span className="chatbot-msg__text">⏳ Processant…</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="chatbot-input-row">
            <input
              type="text"
              className="chatbot-input"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Escriu la teva pregunta…"
              onKeyDown={e => { if (e.key === 'Enter') send(); }}
              disabled={loading}
            />
            <button className="chatbot-send" onClick={send} disabled={loading || !input.trim()}>
              ➤
            </button>
          </div>
        </div>
      )}
      <button
        className={`chatbot-fab ${open ? 'chatbot-fab--open' : ''}`}
        onClick={() => setOpen(o => !o)}
        title="Obre l'assistent RACC"
      >
        {open ? '✕' : '🤖'}
      </button>
    </div>
  );
};
