import React, { useEffect, useState } from 'react';
import { useAuth } from '../AuthContext';
import './Configuracio.css';

const Configuracio: React.FC = () => {
  const { user, fetchWithAuth, logout } = useAuth();
  const [configData, setConfigData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    fetchWithAuth('/api/configuracion')
      .then(r => r.json())
      .then(d => setConfigData(d))
      .catch(() => setError('No s\'ha pogut carregar la configuració.'))
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) {
    return (
      <div className="config-locked">
        <span>🔒</span>
        <h2>Accés restringit</h2>
        <p>Has d'iniciar sessió com a administrador per accedir a la configuració.</p>
      </div>
    );
  }

  return (
    <div className="configuracio">
      <div className="config-profile-card">
        <div className="config-avatar">{user.charAt(0).toUpperCase()}</div>
        <div className="config-profile-info">
          <h3>{user}</h3>
          <span className="config-role">Administrador</span>
        </div>
        <button className="config-logout" onClick={logout}>Sortir</button>
      </div>

      {loading && (
        <div className="config-loading">
          <div className="loading-spinner" />
          <p>Carregant configuració…</p>
        </div>
      )}
      {error && <div className="config-error">⚠️ {error}</div>}

      {configData && (
        <div className="config-sections">
          <div className="config-section">
            <h3>ℹ️ Estat del sistema</h3>
            <div className="config-items">
              <div className="config-item">
                <span>Mode admin</span>
                <span className="config-badge config-badge--green">Actiu</span>
              </div>
              <div className="config-item">
                <span>API Backend</span>
                <span className="config-badge config-badge--green">Connectat</span>
              </div>
              <div className="config-item">
                <span>Font SCT</span>
                <span className="config-badge config-badge--blue">En línia</span>
              </div>
            </div>
          </div>

          <div className="config-section">
            <h3>📊 Gestió de dades</h3>
            <div className="config-items">
              <div className="config-item">
                <span>Datasets</span>
                <a href="#" className="config-link" onClick={e => e.preventDefault()}>
                  Gestionar des de la pàgina Datasets
                </a>
              </div>
              <div className="config-item">
                <span>Informe setmanal</span>
                <a href="#" className="config-link" onClick={e => e.preventDefault()}>
                  Pujar des de la pàgina Informe
                </a>
              </div>
            </div>
          </div>

          <div className="config-section">
            <h3>🔑 Seguretat</h3>
            <div className="config-items">
              <div className="config-item">
                <span>Usuari actiu</span>
                <strong>{user}</strong>
              </div>
              <div className="config-item">
                <span>Autenticació</span>
                <span className="config-badge config-badge--green">JWT actiu</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Configuracio;
