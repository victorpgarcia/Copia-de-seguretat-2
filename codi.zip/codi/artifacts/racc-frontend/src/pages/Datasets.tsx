import React, { useEffect, useState } from 'react';
import { useAuth } from '../AuthContext';
import Modal from '../components/Modal';
import DatasetInsights from '../components/DatasetInsights';
import './Datasets.css';

interface Dataset {
  id: number;
  title: string;
  description: string;
  format: string;
  lastUpdate: string;
  category: string;
  coverage: string;
  link: string;
  logo?: string;
}

const FORMAT_COLORS: Record<string, string> = {
  XML: '#e74c3c',
  CSV: '#27ae60',
  JSON: '#3498db',
  'JSON / CSV': '#2980b9',
  'JSON / REST API': '#8e44ad',
  'CSV / JSON': '#16a085',
  'API REST': '#e67e22',
};

const Datasets: React.FC = () => {
  const { user, fetchWithAuth } = useAuth();
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [selected, setSelected] = useState<Dataset | null>(null);
  const [editModal, setEditModal] = useState(false);
  const [addModal, setAddModal] = useState(false);
  const [form, setForm] = useState<Partial<Dataset>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDatasets = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/datasets');
      const data = await res.json();
      setDatasets(Array.isArray(data) ? data : []);
    } catch { setDatasets([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchDatasets(); }, []);

  const categories = Array.from(new Set(datasets.map(d => d.category)));

  const filtered = datasets.filter(d => {
    const q = search.toLowerCase();
    const matchSearch = !q || d.title.toLowerCase().includes(q) || d.description.toLowerCase().includes(q) || d.coverage.toLowerCase().includes(q);
    const matchCat = !categoryFilter || d.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const openEdit = (d: Dataset) => { setForm({ ...d }); setEditModal(true); setError(null); };
  const openAdd = () => { setForm({}); setAddModal(true); setError(null); };

  const saveEdit = async () => {
    setSaving(true); setError(null);
    try {
      const res = await fetchWithAuth(`/api/datasets/${form.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) { const d = await res.json(); setError(d.detail || 'Error'); return; }
      setEditModal(false);
      fetchDatasets();
    } catch { setError('Error de connexió'); }
    finally { setSaving(false); }
  };

  const saveAdd = async () => {
    setSaving(true); setError(null);
    try {
      const res = await fetchWithAuth('/api/datasets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) { const d = await res.json(); setError(d.detail || 'Error'); return; }
      setAddModal(false);
      fetchDatasets();
    } catch { setError('Error de connexió'); }
    finally { setSaving(false); }
  };

  const deleteDataset = async (id: number) => {
    if (!window.confirm('Segur que vols eliminar aquest dataset?')) return;
    try {
      await fetchWithAuth(`/api/datasets/${id}`, { method: 'DELETE' });
      fetchDatasets();
      if (selected?.id === id) setSelected(null);
    } catch { alert('Error eliminant'); }
  };

  const FormFields = () => (
    <div className="dataset-form">
      {(['title', 'description', 'format', 'lastUpdate', 'category', 'coverage', 'link', 'logo'] as const).map(field => (
        <div key={field} className="form-group">
          <label>{field}</label>
          <input
            type="text"
            value={(form as any)[field] ?? ''}
            onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
            placeholder={field}
          />
        </div>
      ))}
      {error && <p className="form-error">⚠️ {error}</p>}
    </div>
  );

  return (
    <div className="datasets">
      <div className="datasets-toolbar">
        <input
          type="text"
          className="datasets-search"
          placeholder="🔍 Cerca datasets…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select
          className="datasets-filter"
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
        >
          <option value="">Totes les categories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        {user && (
          <button className="btn-add" onClick={openAdd}>＋ Nou dataset</button>
        )}
      </div>

      {loading ? (
        <div className="datasets-loading">
          <div className="loading-spinner" />
          <p>Carregant datasets…</p>
        </div>
      ) : (
        <div className="datasets-grid">
          {filtered.map(d => (
            <div key={d.id} className="dataset-card" onClick={() => setSelected(d === selected ? null : d)}>
              <div className="dataset-card__header">
                {d.logo && (
                  <img src={d.logo} alt="" className="dataset-card__logo" onError={e => (e.currentTarget.style.display = 'none')} />
                )}
                <span className="dataset-card__format" style={{ background: FORMAT_COLORS[d.format] ?? '#6b7280' }}>
                  {d.format}
                </span>
              </div>
              <h3 className="dataset-card__title">{d.title}</h3>
              <p className="dataset-card__desc">{d.description}</p>
              <div className="dataset-card__meta">
                <span>📍 {d.coverage}</span>
                <span>🗂️ {d.category}</span>
                <span>📅 {d.lastUpdate}</span>
              </div>
              <div className="dataset-card__actions" onClick={e => e.stopPropagation()}>
                <a href={d.link} target="_blank" rel="noopener noreferrer" className="btn-link">🔗 Veure font</a>
                {user && (
                  <>
                    <button className="btn-edit" onClick={() => openEdit(d)}>✏️</button>
                    <button className="btn-delete" onClick={() => deleteDataset(d.id)}>🗑️</button>
                  </>
                )}
              </div>
              {selected?.id === d.id && (
                <DatasetInsights datasetId={d.id} format={d.format} title={d.title} />
              )}
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="datasets-empty">Cap dataset trobat amb els filtres actuals.</div>
          )}
        </div>
      )}

      {/* Edit Modal */}
      <Modal isOpen={editModal} onClose={() => setEditModal(false)} title="✏️ Editar dataset" size="lg">
        <FormFields />
        <div className="modal-footer">
          <button className="btn-cancel" onClick={() => setEditModal(false)}>Cancel·lar</button>
          <button className="btn-save" onClick={saveEdit} disabled={saving}>{saving ? 'Guardant…' : 'Guardar'}</button>
        </div>
      </Modal>

      {/* Add Modal */}
      <Modal isOpen={addModal} onClose={() => setAddModal(false)} title="＋ Nou dataset" size="lg">
        <FormFields />
        <div className="modal-footer">
          <button className="btn-cancel" onClick={() => setAddModal(false)}>Cancel·lar</button>
          <button className="btn-save" onClick={saveAdd} disabled={saving}>{saving ? 'Creant…' : 'Crear'}</button>
        </div>
      </Modal>
    </div>
  );
};

export default Datasets;
