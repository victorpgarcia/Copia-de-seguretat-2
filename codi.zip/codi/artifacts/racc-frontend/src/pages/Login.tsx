import React, { useState } from 'react';
import { useAuth } from '../AuthContext';
import './Login.css';

const Login: React.FC = () => {
  const { login, user } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) { setError("Omple tots els camps"); return; }
    setLoading(true); setError(null);
    const ok = await login(username, password);
    setLoading(false);
    if (!ok) setError("Usuari o contrasenya incorrectes");
  };

  if (user) {
    return (
      <div className="login-success">
        <div className="login-success__icon">✅</div>
        <h2>Sessió iniciada com <strong>{user}</strong></h2>
        <p>Ja tens accés als panells de configuració i gestió.</p>
      </div>
    );
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-card__logo">🔒</div>
        <h2 className="login-card__title">Accés administrador</h2>
        <p className="login-card__subtitle">Portal de gestió RACC Mobility Data Hub</p>
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label>Usuari</label>
            <input
              type="text"
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="admin"
              autoComplete="username"
              disabled={loading}
            />
          </div>
          <div className="form-group">
            <label>Contrasenya</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              disabled={loading}
            />
          </div>
          {error && <div className="login-error">⚠️ {error}</div>}
          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? 'Entrant…' : 'Iniciar sessió'}
          </button>
        </form>
        <p className="login-hint">Per defecte: <code>admin / admin</code></p>
      </div>
    </div>
  );
};

export default Login;
