import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../AuthContext';
import './Informe.css';

interface InformeData {
  filename?: string;
  uploaded_at?: string;
  rows?: Record<string, string>[];
  error?: string;
}

const Informe: React.FC = () => {
  const { user, fetchWithAuth } = useAuth();
  const [data, setData] = useState<InformeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadData = () => {
    setLoading(true);
    fetch('/api/informe/datos')
      .then(r => r.json())
      .then(d => setData(d))
      .catch(() => setData({ error: 'No s\'ha pogut carregar l\'informe.' }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true); setUploadError(null);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await fetchWithAuth('/api/informe/csv', { method: 'POST', body: formData });
      if (!res.ok) {
        const d = await res.json();
        setUploadError(d.detail || 'Error pujant');
      } else {
        loadData();
      }
    } catch { setUploadError('Error de connexió'); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ''; }
  };

  const downloadCsv = () => {
    if (!data?.rows?.length) return;
    const headers = Object.keys(data.rows[0]);
    const lines = [headers.join(','), ...data.rows.map(r => headers.map(h => JSON.stringify(r[h] ?? '')).join(','))];
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = data.filename ?? 'informe.csv';
    a.click();
  };

  const downloadPdf = async () => {
    if (!data?.rows?.length) return;
    try {
      const jsPDF = (await import('jspdf')).default;
      const autoTable = (await import('jspdf-autotable')).default;
      const doc = new jsPDF({ orientation: 'landscape' });
      doc.setFontSize(16);
      doc.text('Informe setmanal RACC', 14, 20);
      if (data.uploaded_at) {
        doc.setFontSize(10);
        doc.text(`Pujat: ${data.uploaded_at}`, 14, 28);
      }
      const headers = Object.keys(data.rows[0]);
      autoTable(doc, {
        head: [headers],
        body: data.rows.map(r => headers.map(h => r[h] ?? '')),
        startY: 35,
        styles: { fontSize: 9 },
        headStyles: { fillColor: [26, 26, 46] },
      });
      doc.save('informe_setmanal_racc.pdf');
    } catch (e) {
      alert('Error generant PDF: ' + e);
    }
  };

  const columns = data?.rows?.length ? Object.keys(data.rows[0]) : [];

  return (
    <div className="informe">
      <div className="informe-header-card">
        <div className="informe-header-info">
          <h2>📋 Informe setmanal de mobilitat</h2>
          <p>Visualitza i descarrega l'informe setmanal pujat per l'administrador.</p>
          {data?.filename && <span className="informe-filename">📄 {data.filename}</span>}
          {data?.uploaded_at && <span className="informe-date">📅 {data.uploaded_at}</span>}
        </div>
        <div className="informe-actions">
          {data?.rows?.length ? (
            <>
              <button className="btn-informe" onClick={downloadCsv}>⬇️ CSV</button>
              <button className="btn-informe" onClick={downloadPdf}>📄 PDF</button>
            </>
          ) : null}
          {user && (
            <label className="btn-upload">
              {uploading ? '⏳ Pujant…' : '⬆️ Pujar CSV'}
              <input
                ref={fileRef}
                type="file"
                accept=".csv"
                style={{ display: 'none' }}
                onChange={handleUpload}
                disabled={uploading}
              />
            </label>
          )}
        </div>
      </div>

      {uploadError && <div className="informe-error">⚠️ {uploadError}</div>}

      {loading ? (
        <div className="informe-loading">
          <div className="loading-spinner" />
          <p>Carregant informe…</p>
        </div>
      ) : data?.error ? (
        <div className="informe-empty">
          <span>📭</span>
          <p>{data.error}</p>
          {!user && <p className="informe-hint">Inicia sessió com a admin per pujar l'informe setmanal.</p>}
        </div>
      ) : data?.rows?.length ? (
        <div className="informe-table-wrapper">
          <p className="informe-count">{data.rows.length} files · {columns.length} columnes</p>
          <div className="informe-scroll">
            <table className="informe-table">
              <thead>
                <tr>{columns.map(c => <th key={c}>{c}</th>)}</tr>
              </thead>
              <tbody>
                {data.rows.map((row, i) => (
                  <tr key={i}>
                    {columns.map(c => <td key={c}>{row[c] ?? ''}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="informe-empty">
          <span>📭</span>
          <p>Encara no hi ha cap informe pujat.</p>
          {!user && <p className="informe-hint">Inicia sessió com a admin per pujar l'informe setmanal.</p>}
        </div>
      )}
    </div>
  );
};

export default Informe;
