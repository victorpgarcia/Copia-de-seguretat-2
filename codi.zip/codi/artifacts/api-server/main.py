from typing import Optional, List
import asyncio
import hashlib
import json
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import Response as FastAPIResponse
from sqlmodel import SQLModel, Field, create_engine, Session, select, Column
from sqlalchemy import LargeBinary, inspect as sqlalchemy_inspect, text
from passlib.context import CryptContext
import os
import sys
import threading
from pathlib import Path
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
import uuid
import requests
from lxml import etree
from io import StringIO
import csv
import io

from analizar_dataset_1 import extraer_incidencias
from datasets import extraer_coordenadas_xml

# The uploaded probability pipeline is intentionally kept as the source of
# truth for this feature. It uses only the standard library and live public
# data sources, so the API can reuse it without introducing another model or
# data copy.
ATTACHED_ASSETS_DIR = Path(__file__).resolve().parents[2] / "attached_assets"
if str(ATTACHED_ASSETS_DIR) not in sys.path:
    sys.path.insert(0, str(ATTACHED_ASSETS_DIR))
from unified_accidents_incidencies_1787916936008 import (  # noqa: E402
    COMARQUES_URL,
    DIES_RETARD_METEO,
    INCIDENTS_URL,
    PRECIPITACIO_URL,
    construir_resultats,
    descarregar_comarques,
    descarregar_precipitacio,
    comptar_incidencies_temps_real,
    obtenir_comarca,
)

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./database.db")
SECRET_KEY = os.getenv("SECRET_KEY", "pae_dev_secret_key_change_in_production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "15"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))
HF_API_TOKEN = os.getenv("HF_API_TOKEN")
HF_ENDPOINT = "https://api-inference.huggingface.co/models/gpt2"
PROBABILITY_CACHE_TTL_SECONDS = int(os.getenv("PROBABILITY_CACHE_TTL_SECONDS", "600"))
_probability_cache: dict = {"expires_at": 0.0, "payload": None}
_probability_cache_lock = threading.Lock()
REGISTRY_REFRESH_INTERVAL_SECONDS = 30 * 60
_registry_last_refresh = 0.0
_registry_refresh_lock = threading.Lock()
_registry_refresh_task = None

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")


# ─── SQLModel tables ──────────────────────────────────────────────────────────

class User(SQLModel, table=True):
    __tablename__ = "user"
    __table_args__ = {"extend_existing": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str
    hashed_password: str


class RefreshToken(SQLModel, table=True):
    __tablename__ = "refreshtoken"
    __table_args__ = {"extend_existing": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    jti: str
    user_id: int
    expires_at: datetime
    revoked: bool = False


class Dataset(SQLModel, table=True):
    __tablename__ = "dataset"
    __table_args__ = {"extend_existing": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: str
    format: str
    lastUpdate: str
    category: str
    coverage: str
    link: str
    logo: Optional[str] = None


class InformeCSV(SQLModel, table=True):
    __tablename__ = "informecsv"
    __table_args__ = {"extend_existing": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    filename: str
    content: bytes = Field(sa_column=Column(LargeBinary))
    uploaded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    uploaded_by: str


class IncidentRegistry(SQLModel, table=True):
    """Historical SCT incident registry; coordinates are intentionally omitted."""

    __tablename__ = "incidentregistry"
    __table_args__ = {"extend_existing": True}

    id: Optional[int] = Field(default=None, primary_key=True)
    source_key: str = Field(index=True)
    identificador: Optional[str] = None
    tipus: Optional[str] = None
    subtipus: Optional[str] = None
    carretera: Optional[str] = None
    pk_inici: Optional[str] = None
    pk_fi: Optional[str] = None
    causa: Optional[str] = None
    data: Optional[str] = None
    nivell: Optional[str] = None
    sentit: Optional[str] = None
    descripcio: Optional[str] = None
    descripcio_tipus: Optional[str] = None
    font: Optional[str] = None
    cap_a: Optional[str] = None
    comarca: Optional[str] = None
    status: str = "Active"
    data_final: Optional[datetime] = None
    first_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ─── Seed data ────────────────────────────────────────────────────────────────

DATASETS_SEED = [
    {
        "id": 1,
        "title": "SCT – Incidències viàries Catalunya",
        "description": "Retencions, accidents/obres i estat general de la carretera",
        "format": "XML",
        "lastUpdate": "20/10/2025",
        "category": "Mobilitat",
        "coverage": "Catalunya (inclou AMB)",
        "link": "https://www.gencat.cat/transit/opendata/incidenciesGML.xml",
        "logo": "/gencat.jpg",
    },
    {
        "id": 2,
        "title": "SCT – Portal Open Data (Transport)",
        "description": "Incidències viàries i transport públic (Rodalies). Filtrable per comarca",
        "format": "XML",
        "lastUpdate": "20/10/2025",
        "category": "Mobilitat",
        "coverage": "Catalunya",
        "link": "https://analisi.transparenciacatalunya.cat/?sortBy=relevance&pageSize=20&category=Transport",
        "logo": "/gencat.jpg",
    },
    {
        "id": 3,
        "title": "Dataset RACC",
        "description": "Informació pròpia de l'empresa RACC sobre incidències viàries a Catalunya",
        "format": "CSV",
        "lastUpdate": "Gener 2026",
        "category": "Mobilitat",
        "coverage": "Catalunya",
        "link": "/dataset_racc/dataset_racc.xlsx",
        "logo": "/racc.png",
    },
    {
        "id": 4,
        "title": "Open Data BCN – Transport",
        "description": "Informació general sobre trànsit i mobilitat de vehicles i bicicletes",
        "format": "JSON / CSV",
        "lastUpdate": "20/10/2025",
        "category": "Mobilitat",
        "coverage": "Barcelona ciutat",
        "link": "https://opendata-ajuntament.barcelona.cat/data/ca/organitzacio/transport",
        "logo": "/ajuntamentbcn.jpg",
    },
    {
        "id": 5,
        "title": "TMB – Rutes i parades (Transit API)",
        "description": "Línies de bus i metro, parades i estat de servei",
        "format": "JSON / REST API",
        "lastUpdate": "20/10/2025",
        "category": "Transport públic",
        "coverage": "Catalunya",
        "link": "https://developer.tmb.cat/api-docs/v1/transit",
        "logo": "/img_header_logotmb_red.jpg",
    },
    {
        "id": 6,
        "title": "AMB – Mobilitat urbana",
        "description": "Afeccions a carreteres, accidents, info ZBE i transport públic",
        "format": "CSV / JSON",
        "lastUpdate": "20/10/2025",
        "category": "Mobilitat",
        "coverage": "Comarques de l'AMB",
        "link": "https://www.amb.cat/s/web/mobilitat/mobilitat.html",
        "logo": "/amb.jpg",
    },
    {
        "id": 7,
        "title": "Rodalies – Incidències",
        "description": "Incidències ferroviàries del servei de Rodalies",
        "format": "XML",
        "lastUpdate": "20/10/2025",
        "category": "Transport públic",
        "coverage": "Barcelona i municipis propers",
        "link": "https://www.gencat.cat/rodalies/incidencies_rodalies_rss_ca_ES.xml",
        "logo": "/rodalies.jpg",
    },
    {
        "id": 8,
        "title": "DGT 3.0 – Trànsit temps real",
        "description": "Informació general de trànsit i alertes en temps real",
        "format": "API REST",
        "lastUpdate": "20/10/2025",
        "category": "Mobilitat",
        "coverage": "Espanya",
        "link": "https://github.com/dgt30-esp",
        "logo": "/dgt.jpg",
    },
]


# ─── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(title="RACC PAE Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

engine = create_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)


def get_session():
    with Session(engine) as session:
        yield session


def _ensure_registry_schema() -> None:
    """Add registry columns that are introduced after the initial deployment."""
    inspector = sqlalchemy_inspect(engine)
    if "incidentregistry" not in inspector.get_table_names():
        return

    columns = {column["name"] for column in inspector.get_columns("incidentregistry")}
    with engine.begin() as connection:
        if "data_final" not in columns and engine.dialect.name == "postgresql":
            connection.execute(
                text(
                    "ALTER TABLE incidentregistry "
                    "ADD COLUMN IF NOT EXISTS data_final TIMESTAMP NULL"
                )
            )
        elif "data_final" not in columns:
            connection.execute(
                text("ALTER TABLE incidentregistry ADD COLUMN data_final DATETIME")
            )
        # Rows that became inactive before data_final was introduced do not have
        # an exact transition timestamp. Their last SCT observation is the
        # closest persisted timestamp and prevents historical rows from
        # remaining blank forever.
        connection.execute(
            text(
                "UPDATE incidentregistry "
                "SET data_final = last_seen_at "
                "WHERE status = 'Innactiu' AND data_final IS NULL"
            )
        )


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/token")


# ─── Token helpers ────────────────────────────────────────────────────────────

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire, "iat": now})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token(user_id: int, expires_delta: Optional[timedelta] = None):
    jti = str(uuid.uuid4())
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS))
    payload = {"jti": jti, "sub": str(user_id), "exp": expire, "iat": now}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM), jti, expire


def verify_access_token(token: str) -> int:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return int(payload.get("sub"))
    except JWTError:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")


def get_current_user(token: str = Depends(oauth2_scheme), session: Session = Depends(get_session)):
    user_id = verify_access_token(token)
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no válido")
    return user


# ─── Startup ──────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def on_startup():
    global _registry_refresh_task
    SQLModel.metadata.create_all(engine)
    _ensure_registry_schema()
    with Session(engine) as session:
        existing_ids = {d.id for d in session.exec(select(Dataset)).all()}
        for d in DATASETS_SEED:
            if d["id"] not in existing_ids:
                session.add(Dataset(**d))
        if not session.exec(select(User).where(User.username == "admin")).first():
            session.add(User(username="admin", hashed_password=pwd_context.hash("admin")))
        session.commit()
    _registry_refresh_task = asyncio.create_task(_registry_refresh_loop())


@app.on_event("shutdown")
async def on_shutdown():
    if _registry_refresh_task is not None:
        _registry_refresh_task.cancel()


# ─── Health ───────────────────────────────────────────────────────────────────

@app.get("/api/healthz")
def healthz():
    return {"status": "ok"}


# ─── Auth ─────────────────────────────────────────────────────────────────────

@app.post("/api/login")
def login(data: dict, session: Session = Depends(get_session)):
    username = data.get("username")
    password = data.get("password")
    user = session.exec(select(User).where(User.username == username)).first()
    if not user or not pwd_context.verify(password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")
    access_token = create_access_token({"sub": str(user.id)})
    refresh_token, jti, expires_at = create_refresh_token(user.id)
    session.add(RefreshToken(jti=jti, user_id=user.id, expires_at=expires_at, revoked=False))
    session.commit()
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "username": username,
    }


@app.post("/api/refresh")
def refresh_token_endpoint(data: dict, session: Session = Depends(get_session)):
    token = data.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="No refresh token")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        jti = payload.get("jti")
        user_id = int(payload.get("sub"))
    except JWTError:
        raise HTTPException(status_code=401, detail="Refresh token inválido")

    rt = session.exec(select(RefreshToken).where(RefreshToken.jti == jti)).first()
    if not rt or rt.revoked:
        raise HTTPException(status_code=401, detail="Refresh token revocado o no encontrado")

    rt.revoked = True
    session.add(rt)

    new_access = create_access_token({"sub": str(user_id)})
    new_refresh, new_jti, new_expires = create_refresh_token(user_id)
    session.add(RefreshToken(jti=new_jti, user_id=user_id, expires_at=new_expires, revoked=False))
    session.commit()
    return {"access_token": new_access, "refresh_token": new_refresh, "token_type": "bearer"}


@app.post("/api/logout")
def logout(data: dict, session: Session = Depends(get_session)):
    token = data.get("refresh_token")
    if token:
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            jti = payload.get("jti")
            rt = session.exec(select(RefreshToken).where(RefreshToken.jti == jti)).first()
            if rt:
                rt.revoked = True
                session.add(rt)
                session.commit()
        except JWTError:
            pass
    return {"msg": "Logout exitoso"}


@app.get("/api/me")
def me(token: str = Depends(oauth2_scheme), session: Session = Depends(get_session)):
    user_id = verify_access_token(token)
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no válido")
    return {"username": user.username}


# ─── Datasets ─────────────────────────────────────────────────────────────────

@app.get("/api/datasets")
def list_datasets(session: Session = Depends(get_session)):
    return session.exec(select(Dataset).order_by(Dataset.id)).all()


@app.get("/api/datasets/{dataset_id}")
def get_dataset(dataset_id: int, session: Session = Depends(get_session)):
    ds = session.get(Dataset, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    return ds


@app.post("/api/datasets", status_code=201)
def create_dataset(payload: dict, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    existing = session.exec(select(Dataset)).all()
    if not payload.get("id"):
        payload["id"] = max([d.id for d in existing], default=0) + 1
    ds = Dataset(**payload)
    session.add(ds)
    session.commit()
    session.refresh(ds)
    return ds


@app.put("/api/datasets/{dataset_id}")
def update_dataset(
    dataset_id: int,
    payload: dict,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    existing = session.get(Dataset, dataset_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    for field in ["title", "description", "format", "lastUpdate", "category", "coverage", "link", "logo"]:
        if field in payload:
            setattr(existing, field, payload[field])
    session.add(existing)
    session.commit()
    session.refresh(existing)
    return existing


@app.delete("/api/datasets/{dataset_id}", status_code=204)
def delete_dataset(dataset_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    ds = session.get(Dataset, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    session.delete(ds)
    session.commit()


# ─── Configuració ─────────────────────────────────────────────────────────────

@app.get("/api/configuracion")
def configuracion(user: User = Depends(get_current_user)):
    return {"message": "Configuració admin correcta", "admin": True}


# ─── Incidents helpers ────────────────────────────────────────────────────────

def _fetch_incidencies() -> List[dict]:
    try:
        xml = requests.get(
            "https://www.gencat.cat/transit/opendata/incidenciesGML.xml", timeout=15
        ).text
        return extraer_incidencias(xml)
    except Exception as e:
        print(f"Error fetching incidencies: {e}")
        return []


def _nivel(i: dict) -> int:
    for key in ("nivell", "nivel"):
        try:
            return int(i.get(key, 0))
        except (TypeError, ValueError):
            pass
    return 0


REGISTRY_FIELDS = (
    "identificador",
    "tipus",
    "subtipus",
    "carretera",
    "pk_inici",
    "pk_fi",
    "causa",
    "data",
    "nivell",
    "sentit",
    "descripcio",
    "descripcio_tipus",
    "font",
    "cap_a",
    "comarca",
)


def _registry_source_key(incident: dict) -> str:
    """Prefer SCT's stable incident id, with a deterministic fallback."""
    source_id = incident.get("identificador")
    if source_id not in (None, ""):
        return f"sct:{source_id}"

    identity = "|".join(
        str(incident.get(field, ""))
        for field in (
            "carretera",
            "pk_inici",
            "pk_fi",
            "data",
            "descripcio",
            "sentit",
            "latitud",
            "longitud",
        )
    )
    return "fingerprint:" + hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _registry_values(incident: dict, comarca: Optional[str]) -> dict:
    values = {
        field: incident.get(field)
        for field in REGISTRY_FIELDS
        if field != "comarca"
    }
    values["comarca"] = comarca
    # Keep source values displayable exactly as published, including values
    # that occasionally change type between SCT feed versions.
    return {
        field: None if value in (None, "") else str(value).strip()
        for field, value in values.items()
    }


def _refresh_registry_once() -> int:
    """Persist the current SCT feed and mark disappeared rows inactive."""
    global _registry_last_refresh

    with _registry_refresh_lock:
        response = requests.get(
            INCIDENTS_URL,
            headers={"User-Agent": "racc-mobility-data-hub/1.0"},
            timeout=30,
        )
        response.raise_for_status()
        incidents = extraer_incidencias(response.text)
        comarca_shapes = descarregar_comarques()
        now = datetime.now(timezone.utc)

        incoming = {}
        for incident in incidents:
            comarca = None
            try:
                latitude = float(incident["latitud"])
                longitude = float(incident["longitud"])
                comarca = obtenir_comarca(latitude, longitude, comarca_shapes)
            except (KeyError, TypeError, ValueError):
                pass
            incoming[_registry_source_key(incident)] = (
                incident,
                comarca,
            )

        with Session(engine) as session:
            stored_rows = session.exec(select(IncidentRegistry)).all()
            by_source_key = {row.source_key: row for row in stored_rows}

            for source_key, (incident, comarca) in incoming.items():
                row = by_source_key.get(source_key)
                values = _registry_values(incident, comarca)
                if row is None:
                    row = IncidentRegistry(
                        source_key=source_key,
                        **values,
                        status="Active",
                        first_seen_at=now,
                        last_seen_at=now,
                    )
                    session.add(row)
                else:
                    for field, value in values.items():
                        setattr(row, field, value)
                    row.status = "Active"
                    row.last_seen_at = now
                    session.add(row)

            incoming_keys = set(incoming)
            for row in stored_rows:
                if row.source_key not in incoming_keys:
                    if row.status == "Active":
                        row.status = "Innactiu"
                        row.data_final = now
                        session.add(row)
                    elif row.status == "Innactiu" and row.data_final is None:
                        # Defensive backfill for databases upgraded without
                        # the startup migration or rows created by an older
                        # registry implementation.
                        row.data_final = row.last_seen_at or now
                        session.add(row)

            session.commit()

        _registry_last_refresh = now.timestamp()
        return len(incoming)


async def _registry_refresh_loop():
    """Keep the historical registry synchronized every thirty minutes."""
    await asyncio.sleep(1)
    while True:
        try:
            await asyncio.to_thread(_refresh_registry_once)
        except Exception as error:
            print(f"Registry refresh failed: {error}")
        await asyncio.sleep(REGISTRY_REFRESH_INTERVAL_SECONDS)


def _registry_to_dict(row: IncidentRegistry) -> dict:
    return {
        "id": row.id,
        "status": row.status,
        **{field: getattr(row, field) for field in REGISTRY_FIELDS},
        "data_final": row.data_final.isoformat() if row.data_final else None,
        "first_seen_at": row.first_seen_at.isoformat(),
        "last_seen_at": row.last_seen_at.isoformat(),
    }


def _ensure_registry_fresh(session: Session) -> None:
    """Populate the registry on first use and recover after a restart."""
    has_rows = session.exec(select(IncidentRegistry.id).limit(1)).first() is not None
    now = datetime.now(timezone.utc).timestamp()
    is_stale = (
        _registry_last_refresh == 0
        or now - _registry_last_refresh >= REGISTRY_REFRESH_INTERVAL_SECONDS
    )
    if not has_rows or is_stale:
        _refresh_registry_once()


# ─── Incident endpoints ───────────────────────────────────────────────────────

@app.get("/api/incidencies/raw")
def api_raw():
    return {"incidencies": _fetch_incidencies()}


@app.get("/api/incidencies/summary")
def api_summary():
    incs = _fetch_incidencies()
    total = len(incs)
    greus = sum(1 for i in incs if _nivel(i) >= 3)
    pct = round(greus / total * 100, 2) if total else 0

    road_counts: dict = {}
    for i in incs:
        r = i.get("carretera")
        if r:
            road_counts[r] = road_counts.get(r, 0) + 1
    via_mes = None
    if road_counts:
        best = max(road_counts.items(), key=lambda x: x[1])
        via_mes = {"carretera": best[0], "incidents": best[1]}

    return {"total_incidents": total, "percent_greus": pct, "via_mes_afectada": via_mes}


@app.get("/api/incidencies/by_tipo")
def api_by_tipo():
    incs = _fetch_incidencies()
    tipos: dict = {}
    for i in incs:
        t = str(i.get("descripcio_tipus") or i.get("tipus") or "Desconegut")
        tipos[t] = tipos.get(t, 0) + 1
    return {"by_tipo": tipos}


@app.get("/api/incidencies/by_nivel")
def api_by_nivel():
    incs = _fetch_incidencies()
    niveles: dict = {}
    for i in incs:
        n = str(_nivel(i))
        niveles[n] = niveles.get(n, 0) + 1
    return {"by_nivel": niveles}


@app.get("/api/incidencies/ranking_trams")
def api_ranking():
    incs = _fetch_incidencies()
    trams: dict = {}
    for i in incs:
        road = i.get("carretera")
        if not road:
            continue
        if road not in trams:
            trams[road] = {"carretera": road, "incidents": 0, "max_nivel": 0, "tipo_principal": None}
        trams[road]["incidents"] += 1
        n = _nivel(i)
        if n > trams[road]["max_nivel"]:
            trams[road]["max_nivel"] = n
        tipo = i.get("descripcio_tipus") or i.get("tipus")
        if tipo and not trams[road]["tipo_principal"]:
            trams[road]["tipo_principal"] = str(tipo)
    ranked = sorted(trams.values(), key=lambda x: x["incidents"], reverse=True)
    return {"ranking": ranked[:20]}


@app.get("/api/registre")
def api_registre(
    status: Optional[str] = None,
    search: Optional[str] = None,
    session: Session = Depends(get_session),
):
    _ensure_registry_fresh(session)

    statement = select(IncidentRegistry).order_by(IncidentRegistry.id)
    normalized_status = (status or "").lower()
    if normalized_status == "active":
        statement = statement.where(IncidentRegistry.status == "Active")
    elif normalized_status in {"innactiu", "inactiu"}:
        statement = statement.where(IncidentRegistry.status == "Innactiu")

    rows = session.exec(statement).all()
    if search:
        needle = search.casefold()
        rows = [
            row
            for row in rows
            if needle in " ".join(
                str(getattr(row, field) or "") for field in REGISTRY_FIELDS
            ).casefold()
        ]

    active_count = sum(row.status == "Active" for row in rows)
    inactive_count = sum(row.status == "Innactiu" for row in rows)
    last_refresh = _registry_last_refresh
    if last_refresh == 0 and rows:
        last_refresh = max(row.last_seen_at.timestamp() for row in rows)

    return {
        "rows": [_registry_to_dict(row) for row in rows],
        "active_count": active_count,
        "inactive_count": inactive_count,
        "total_count": len(rows),
        "last_refresh": (
            datetime.fromtimestamp(last_refresh, timezone.utc).isoformat()
            if last_refresh
            else None
        ),
        "refresh_interval_minutes": 30,
    }


def _build_probability_payload() -> dict:
    """Run the uploaded unified pipeline once and shape it for the UI."""
    precipitation, weather_date, month_start = descarregar_precipitacio()
    comarca_shapes = descarregar_comarques()
    incidents_by_comarca, without_coordinates, outside_comarca = (
        comptar_incidencies_temps_real(comarca_shapes)
    )
    rows = construir_resultats(precipitation, incidents_by_comarca)

    available_rows = [row for row in rows if row["probabilitat_nou_accident_pct"] is not None]
    highest_probability = max(
        available_rows,
        key=lambda row: row["probabilitat_nou_accident_pct"],
        default=None,
    )
    highest_incidents = max(
        rows,
        key=lambda row: row["incidencies_temps_real"],
        default=None,
    )
    average_probability = (
        round(
            sum(row["probabilitat_nou_accident_pct"] for row in available_rows)
            / len(available_rows),
            2,
        )
        if available_rows
        else None
    )

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "weather_date": weather_date,
        "month_start": month_start,
        "weather_delay_days": DIES_RETARD_METEO,
        "sources": {
            "precipitation": PRECIPITACIO_URL,
            "comarques": COMARQUES_URL,
            "incidents": INCIDENTS_URL,
        },
        "quality": {
            "without_coordinates": without_coordinates,
            "outside_comarca": outside_comarca,
            "comarques_with_weather": sum(
                1 for row in rows if row["precipitacio_disponible"]
            ),
            "total_comarques": len(rows),
        },
        "summary": {
            "average_probability_pct": average_probability,
            "highest_probability": highest_probability,
            "highest_incidents": highest_incidents,
            "total_live_incidents": sum(
                row["incidencies_temps_real"] for row in rows
            ),
        },
        "results": rows,
    }


@app.get("/api/probabilitat-accidents")
def api_probabilitat_accidents():
    """
    Returns one probability dashboard dataset per comarca.

    The first request runs the uploaded precipitation + boundaries + SCT
    pipeline. Subsequent requests reuse the same live snapshot for ten minutes
    so navigating, refreshing, or opening the iframe remains responsive.
    """
    now = datetime.now(timezone.utc).timestamp()
    with _probability_cache_lock:
        if (
            _probability_cache["payload"] is not None
            and _probability_cache["expires_at"] > now
        ):
            return _probability_cache["payload"]

    try:
        payload = _build_probability_payload()
    except Exception as error:
        raise HTTPException(
            status_code=502,
            detail=f"No s'han pogut actualitzar les dades de probabilitat: {error}",
        ) from error

    with _probability_cache_lock:
        _probability_cache["payload"] = payload
        _probability_cache["expires_at"] = now + PROBABILITY_CACHE_TTL_SECONDS
    return payload


@app.get("/api/coordenadas")
def obtener_coordenadas():
    return {"coordenadas": extraer_coordenadas_xml()}


@app.get("/api/incidencias")
def obtener_incidencias():
    return {"incidencias": _fetch_incidencies()}


# ─── Dataset XML helpers ──────────────────────────────────────────────────────

def _download_xml(url: str) -> str:
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        return r.text
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Error descargando XML: {e}")


def _xml_to_txt(xml_content: str) -> str:
    try:
        root = etree.fromstring(xml_content.encode("utf-8"))
        out = StringIO()
        out.write("=" * 80 + "\n")
        out.write("CONTINGUT XML CONVERTIT A TXT\n")
        out.write("=" * 80 + "\n\n")

        def procesar(elem, level=0):
            indent = "  " * level
            out.write(f"{indent}[{elem.tag}]\n")
            for k, v in elem.attrib.items():
                out.write(f"{indent}  @{k}: {v}\n")
            if elem.text and elem.text.strip():
                out.write(f"{indent}  > {elem.text.strip()}\n")
            for child in elem:
                procesar(child, level + 1)

        procesar(root)
        out.write("\n" + "=" * 80 + "\n")
        return out.getvalue()
    except etree.XMLSyntaxError as e:
        raise HTTPException(status_code=400, detail=f"Error parseando XML: {e}")


@app.get("/api/datasets/{dataset_id}/analyze-xml")
def analyze_xml(dataset_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    ds = session.get(Dataset, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    if "XML" not in ds.format:
        raise HTTPException(status_code=400, detail="Dataset no es XML")
    xml_content = _download_xml(ds.link)
    try:
        incs = extraer_incidencias(xml_content)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error extrayendo incidencias: {e}")
    tipos: dict = {}
    carreteras: dict = {}
    for i in incs:
        t = str(i.get("descripcio_tipus") or i.get("tipus") or "?")
        tipos[t] = tipos.get(t, 0) + 1
        r = str(i.get("carretera") or "?")
        carreteras[r] = carreteras.get(r, 0) + 1
    return {
        "dataset_id": dataset_id,
        "dataset_title": ds.title,
        "total": len(incs),
        "by_tipo": tipos,
        "by_road_top10": sorted(carreteras.items(), key=lambda x: x[1], reverse=True)[:10],
        "sample": incs[0] if incs else None,
    }


@app.get("/api/datasets/{dataset_id}/xml-to-txt")
def xml_to_txt_endpoint(dataset_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    ds = session.get(Dataset, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    if "XML" not in ds.format:
        raise HTTPException(status_code=400, detail="Dataset no es XML")
    xml_content = _download_xml(ds.link)
    txt = _xml_to_txt(xml_content)
    return {"dataset_id": dataset_id, "dataset_title": ds.title, "content": txt}


@app.get("/api/datasets/{dataset_id}/xml-download")
def xml_download(dataset_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    ds = session.get(Dataset, dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset no encontrado")
    if "XML" not in ds.format:
        raise HTTPException(status_code=400, detail="Dataset no es XML")
    xml_content = _download_xml(ds.link)
    return FastAPIResponse(
        content=xml_content,
        media_type="application/xml",
        headers={"Content-Disposition": f"attachment; filename=dataset_{dataset_id}.xml"},
    )


# ─── Chatbot ──────────────────────────────────────────────────────────────────

@app.post("/api/chatbot/ask")
async def chatbot_ask(data: dict):
    context = data.get("context", "")
    question = data.get("question", "")
    try:
        prompt = f"Context: {context[:2000]}\nPregunta: {question}\nResposta:"
        if HF_API_TOKEN:
            headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}
            payload = {
                "inputs": prompt,
                "parameters": {"max_new_tokens": 150, "temperature": 0.7},
            }
            r = requests.post(HF_ENDPOINT, json=payload, headers=headers, timeout=15)
            if r.ok:
                resp = r.json()
                answer = resp[0].get("generated_text", str(resp)) if isinstance(resp, list) else str(resp)
            else:
                answer = "El servei de chatbot no està disponible en aquest moment."
        else:
            q = question.lower()
            if "incident" in q or "incidència" in q:
                answer = "Basant-me en el context, hi ha diverses incidències actives a la xarxa viària de Catalunya."
            elif "carretera" in q:
                answer = "El document conté informació sobre diverses carreteres de Catalunya."
            else:
                answer = f"He rebut la pregunta: «{question}». Configura HF_API_TOKEN per obtenir respostes detallades."
        return {"answer": answer}
    except Exception as e:
        return {"answer": f"Error: {str(e)}"}


# ─── Informe setmanal ─────────────────────────────────────────────────────────

@app.post("/api/informe/csv", status_code=201)
def upload_informe(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):
    if user.username != "admin":
        raise HTTPException(status_code=403, detail="Només l'admin pot pujar l'informe setmanal")
    content = file.file.read()
    informe = InformeCSV(filename=file.filename, content=content, uploaded_by=user.username)
    session.add(informe)
    session.commit()
    session.refresh(informe)
    return {"msg": "Informe pujat", "id": informe.id, "filename": informe.filename}


@app.get("/api/informe/datos")
def get_informe(session: Session = Depends(get_session)):
    informe = session.exec(select(InformeCSV).order_by(InformeCSV.uploaded_at.desc())).first()
    if not informe:
        return {"error": "No hi ha cap informe setmanal disponible"}
    try:
        text = informe.content.decode("utf-8")
    except UnicodeDecodeError:
        text = informe.content.decode("latin-1")
    reader = csv.DictReader(io.StringIO(text))
    rows = list(reader)
    return {"filename": informe.filename, "uploaded_at": str(informe.uploaded_at), "rows": rows}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8080"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
