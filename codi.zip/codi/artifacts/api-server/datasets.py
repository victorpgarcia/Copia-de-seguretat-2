import requests
from lxml import etree
from typing import List, Dict, Any, Optional

DATASET_URL = "https://www.gencat.cat/transit/opendata/incidenciesGML.xml"

def descargar_xml(url: str = DATASET_URL) -> str:
    response = requests.get(url, timeout=15)
    response.raise_for_status()
    return response.text


def extraer_coordenadas_xml(url: str = DATASET_URL) -> List[Dict[str, Any]]:
    """
    Extrae coordenadas básicas del XML GML de la SCT.
    Retorna lista de {longitud, latitud}.
    """
    try:
        xml_content = descargar_xml(url)
        root = etree.fromstring(xml_content.encode('utf-8'))
        namespaces = {
            'wfs': 'http://www.opengis.net/wfs',
            'gml': 'http://www.opengis.net/gml',
            'cite': 'http://www.opengeospatial.net/cite'
        }
        coordenadas = []
        for coords_elem in root.findall('.//gml:coordinates', namespaces):
            if coords_elem.text:
                try:
                    lon, lat = coords_elem.text.strip().split(',')
                    coordenadas.append({'longitud': float(lon), 'latitud': float(lat)})
                except (ValueError, AttributeError):
                    continue
        return coordenadas
    except Exception as e:
        print(f"Error extrayendo coordenadas: {e}")
        return []


def extraer_coordenadas_con_detalles(url: str = DATASET_URL) -> List[Dict[str, Any]]:
    """
    Extrae coordenadas con información detallada de las incidencias.
    """
    try:
        xml_content = descargar_xml(url)
        root = etree.fromstring(xml_content.encode('utf-8'))
        namespaces = {
            'wfs': 'http://www.opengis.net/wfs',
            'gml': 'http://www.opengis.net/gml',
            'cite': 'http://www.opengeospatial.net/cite'
        }
        features = []
        for feature_member in root.findall('.//gml:featureMember', namespaces):
            feature = feature_member.find('.//cite:mct2_v_afectacions_data', namespaces)
            if feature is None:
                continue
            item: Dict[str, Any] = {}

            coords = feature.find('.//gml:coordinates', namespaces)
            if coords is not None and coords.text:
                try:
                    lon, lat = coords.text.strip().split(',')
                    item['longitud'] = float(lon)
                    item['latitud'] = float(lat)
                except (ValueError, AttributeError):
                    continue

            camp_map = {
                'identificador': 'int',
                'tipus': 'int',
                'subtipus': 'int',
                'carretera': 'str',
                'pk_inici': 'float',
                'pk_fi': 'float',
                'causa': 'str',
                'data': 'str',
                'nivell': 'int',
                'sentit': 'str',
                'descripcio': 'str',
                'descripcio_tipus': 'str',
                'font': 'str',
                'cap_a': 'str',
            }
            for camp, tipus in camp_map.items():
                elem = feature.find(f'cite:{camp}', namespaces)
                if elem is not None and elem.text:
                    valor = elem.text.strip()
                    if tipus == 'int':
                        try:
                            item[camp] = int(valor)
                        except ValueError:
                            item[camp] = valor
                    elif tipus == 'float':
                        try:
                            item[camp] = float(valor)
                        except ValueError:
                            item[camp] = valor
                    else:
                        item[camp] = valor
            features.append(item)
        return features
    except Exception as e:
        print(f"Error extrayendo coordenadas con detalles: {e}")
        return []
